import React, { Suspense } from 'react';
import { BrowserRouter,Routes,Route } from "react-router-dom";
import { HomeScreen } from './login-module/home-screen';
import { Header } from './pet-module/header';
//import { PageNotFound } from './login-module/page-not-fount';
//import { MyPets } from './pet-module/my-pets';
//import { AddPets } from './pet-module/add-pets';
//import { Logout } from './pet-module/logout';
//import { PetDashboard } from './pet-module/pet-dashboard';
//import { RegisterSuccess } from './login-module/register-success';

// const Login= React.lazy(() => import('./login-module/login.js'));
// const Register = React.lazy(() => import('./login-module/register.js'));
// const RegisterSuccess= React.lazy(() => import('./login-module/register-success.js'));
const PetDashboard = React.lazy(() => import('./pet-module/pet-dashboard.js'));
const BorrowedBooks= React.lazy(() => import('./pet-module/borrowedBooks.js'));
const AddPets = React.lazy(() => import('./pet-module/add-pets.js'));
const Logout = React.lazy(() => import('./pet-module/logout.js'));
const PageNotFound = React.lazy(() => import('./login-module/page-not-fount.js'));





export function PetRouter() {
  return (
    <div>
        <BrowserRouter>
        <Header />
            <Routes>
                {/* <Route path="/" element={<HomeScreen/>} /> */}
                {/* <Route path="login" element={<Suspense fallback="Loading....."> <Login /></Suspense>}></Route>
                <Route path="register" element={<Suspense fallback="Loading....."> <Register /></Suspense>}></Route>
                <Route path="registerSuccess" element={<Suspense fallback="Loading....."> <RegisterSuccess /></Suspense>}></Route> */}
                <Route exact path="/" element={<Suspense fallback="Loading....."> <PetDashboard /></Suspense>}></Route>
                <Route exact path="home" element={<Suspense fallback="Loading....."> <PetDashboard /></Suspense>}></Route>
                <Route exact path="borrowedBooks" element={<Suspense fallback="Loading....."> <BorrowedBooks /></Suspense>}></Route>
                <Route path="addPets" element={<Suspense fallback="Loading....."> <AddPets /></Suspense>}></Route>
                <Route path="logout" element={<Suspense fallback="Loading....."> <Logout /></Suspense>}></Route>
                <Route path="*" element={<Suspense fallback="Loading....."> <PageNotFound /></Suspense>}></Route>
            </Routes>
        </BrowserRouter>  
    </div>
  );
}