
export default function RegisterSuccess() {
 return (
    <div className='registerSuccess'>
        <p>You have registered Succesfully!! please <a href="/login">Sign in Here</a> </p>  
    </div>
  );
}
