import React, {useState } from 'react'
import { Form, Button, Modal } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { ModalComponent } from '../pet-module/modal';
import { fetchData, storeData } from '../store/reducer';
//import 

export default function PageNotFound(props) {
  const [modalShow, setModalShow] = React.useState(false);
  const state = useSelector((state) => state);
  const [formValues, setFormValues] = useState({
    name: "",
    age: "",
    place: "",
  });
  const [validated, setValidated] = useState(false);
  //const [flag, setFlag] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.preventDefault();
      e.stopPropagation();
      setValidated(true);
      return;
    }
    //setFlag(true);
    console.log('formValues',formValues);
    dispatch(storeData(formValues));
    e.preventDefault();
    setTimeout(() => {
      console.log('state',state);
      //navigate('/home');
  }, 500)
    
    
    // 
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };
 return (
   <div>
  <Form
  className="w-50 m-auto"
  onSubmit={(e) => handleSubmit(e)}
  noValidate
  validated={validated}
> <h1>Page not found</h1>
  <Form.Group
    className="mb-4"
    id="name"
    controlId="validationCustom02"
  >
    <Form.Label className="d-flex">Pet Name</Form.Label>
    <Form.Control
      type="text"
      placeholder="Enter Pet Name"
      required
      value={formValues.name}
      onChange={(e) => handleInputChange(e)}
      name="name"
    />
    <Form.Control.Feedback type="invalid">
      Please provide a valid name.
    </Form.Control.Feedback>
  </Form.Group>

  <Form.Group className="mb-4" id="age" controlId="validationCustom03">
    <Form.Label className="d-flex">Age</Form.Label>
    <Form.Control
      type="text"
      placeholder="Enter Age"
      required
      value={formValues.age}
      onChange={(e) => handleInputChange(e)}
      name="age"
    />
    <Form.Control.Feedback type="invalid">
      Please provide a valid age.
    </Form.Control.Feedback>
  </Form.Group>

  <Form.Group className="mb-4" id="place" controlId="validationCustom05">
    <Form.Label className="d-flex">Place</Form.Label>
    <Form.Control
      type="text"
      placeholder="Enter Place"
      required
      value={formValues.place}
      onChange={(e) => handleInputChange(e)}
      name="place"
    />
    <Form.Control.Feedback type="invalid">
      Please provide a valid place.
    </Form.Control.Feedback>
  </Form.Group>
  <Form.Group className="mb-4 d-flex">
    <Form.Check
      required
      label="Agree to terms and conditions"
      feedback="You must agree before submitting."
      feedbackType="invalid"
    />
  </Form.Group>
  <Button as="input" type="submit" className="mb-4" value="Submit" onClick={() => setModalShow(true)}/>
  <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
</Form>
</div>
  );
}






function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Modal heading
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <h4>Centered Modal</h4>
        <p>
          Cras mattis consectetur purus sit amet fermentum. Cras justo odio,
          dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta ac
          consectetur ac, vestibulum at eros.
        </p>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}
