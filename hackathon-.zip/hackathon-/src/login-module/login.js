import { useState } from 'react';
import {Form,Row,Col,Button} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import {  useDispatch } from "react-redux";
import { storeData } from '../store/reducer';
import '../css-components/login.css';

export default function Login() {
  //const state = useSelector((state) => state);
  const navigate = useNavigate();
  const [validated, setValidated] = useState(false);
  const dispatch = useDispatch();
  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === true) {
      event.preventDefault();
      event.stopPropagation();
    }
    let loginInfo = {
      name: event.target[0].value,
      password: event.target[1].value,
    }
   dispatch(storeData(loginInfo));
    
    navigate('/home');
    setValidated(true);
  };
  return (
    <div className='login mt-2'>
      <Form  validated={validated} onSubmit={handleSubmit}>
        <h3>Login</h3>
        <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
          <Form.Label column sm={2}>
            Email
          </Form.Label>
          <Col sm={10}>
            <Form.Control type="email" placeholder="Email" />
          </Col>
        </Form.Group>
        <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
          <Form.Label column sm={2}>
            Password
          </Form.Label>
          <Col sm={10}>
            <Form.Control type="password" placeholder="Password" />
          </Col>
        </Form.Group>
        <Button id="#btn" variant="primary" className="mt-4 mb-4" type="submit">
          Submit
        </Button>
      </Form>
   </div>
  );
}