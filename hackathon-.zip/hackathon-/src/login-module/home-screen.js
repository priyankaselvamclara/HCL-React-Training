import React from "react";
import SimpleImageSlider from "react-simple-image-slider";
import { Button } from "react-bootstrap";
import '../css-components/home-screen.css';
import { Link } from "react-router-dom";


export function HomeScreen() {
  const images = [
    { url: 'assests/dog.jpg' },
    { url: 'assests/parrot.jpg' },
    { url: 'assests/cat.jpg' },
    { url: 'assests/rabbit.jpg' }
  ];
  return (
    <>
      <div className="container-fluid homeScreen">
        <div className="row">
          <div className="col">
            <h1>LOGIN/REGISTER TO BUY A NEW PET</h1>
            <SimpleImageSlider width={'100%'} height={'100%'} images={images} showBullets={true} showNavs={true} autoPlay={true}/>
            <div className="buttonBlock">
              <div className="login-btn"><Button variant="primary"><Link to="/login">Login</Link></Button>
              <span>If member, please login</span></div>
              <div className="register-btn"><Button variant="secondary"><Link to="/register">Register</Link></Button>
              <span>If not a member yet, please register</span></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}