import { useState } from 'react';
import {Form,Row,Col,Button} from 'react-bootstrap';
import { useDispatch,useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import '../css-components/login.css';
import { fetchData } from '../store/reducer';

export default function Register() {
  const [validated, setValidated] = useState(false);
  const state = useSelector((state) => state);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    //const form = event.currentTarget;
   /* if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }*/
    let registerInfo = {
      name: event.target[0].value,
      password: event.target[1].value,
  }
  console.log('state',state);
    dispatch(fetchData(state.data, registerInfo.name));
    console.log('data',state, registerInfo);
    if(state.data.name !== registerInfo.name){
    navigate('/registerSuccess');
      //return <RegisterSuccess />;
    } else {
      navigate('/login');
    }
  };
    return (
       <div className='register'>
    <Form  validated={validated} onSubmit={handleSubmit}>
        <h3>Register</h3>
        <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
          <Form.Label column sm={2}>
            Email
          </Form.Label>
          <Col sm={10}>
            <Form.Control type="email" placeholder="Email" />
          </Col>
        </Form.Group>
        <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
          <Form.Label column sm={2}>
            Password
          </Form.Label>
          <Col sm={10}>
            <Form.Control type="password" placeholder="Password" />
          </Col>
        </Form.Group>
        <Form.Group as={Row} className="mb-3" controlId="formHorizontalConfirmPassword">
          <Form.Label column sm={2}>
            Confirm Password
          </Form.Label>
          <Col sm={10}>
            <Form.Control type="password" placeholder="Confirm Password" />
          </Col>
        </Form.Group>
        <Button variant="primary" className="mt-4 mb-4" type="submit">
          Submit
        </Button>
      </Form>
       </div>
     );
   }