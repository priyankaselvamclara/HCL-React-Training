import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button, Table, Modal} from "react-bootstrap";

export default function BorrowedBooks() {
    const [modalShow, setModalShow] = useState(false);
    /*const book = [{
        id: 24,
        title: 'The Three Bears',
        author: 'Rofl Kadal',
        category: 'Fantasy',
        status: 'Borrowed',
        returnDate: '08-05-2022'}]*/
        const state = useSelector((state) => state);
   // const [borrowedBooks, setBorrowedBooks] = useState(book);
    
    const navigate = useNavigate();
    const backToListing =(e)=> {
        navigate('/');
          e.preventDefault();
          e.stopPropagation(); 
    }
   
    return (
        <div className="borrowedBooks">
            <h1>Borrowed Books</h1>
            <Table striped bordered hover>
              <thead>
                  <tr>
                    <th>Book Id</th>
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Book Category</th>
                    <th>Book Status</th>
                    <th>Book Return Date</th>
                    <th>Return Book Action</th>
                  </tr>
              </thead>
              <tbody>
                  {
                   state.data.map((book, i) => {
                          return (
                              <tr key={book.id}>
                                  <td>{book.id}</td>
                                  <td>{book.title}</td>
                                  <td>{book.author}</td>
                                  <td>{book.category}</td>
                                  <td>{book.status}</td>
                                  <td>{book.returnDate}</td>
                                  <td>
                                      <div className="d-flex">
                                          <Button variant="primary"
                                              className="d-flex ms-auto me-3" size="sm">Return Book</Button>
                                      </div>
                                  </td>
                              </tr>
                          )
                      })
                  }
              </tbody>
          </Table>
          <Button onClick={backToListing}>Back to Listing</Button>
         <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
        </div>
    );
}


function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Book Borrow Limit Exceeded
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
          Please return book to borrow another book
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }
   