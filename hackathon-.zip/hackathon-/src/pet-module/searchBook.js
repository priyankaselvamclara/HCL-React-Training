import React, { useContext, useEffect, useState } from "react";
import { Button, Table, Modal} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { petDetailsContext } from "./pet-dashboard";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { storeData } from "../store/reducer";
require('react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css');
var bookDetails = require('../json-data/books.json');

export default function SearchBook(props) {
  const navigate = useNavigate();
  const [modalShow, setModalShow] = React.useState(false);
  let initialValue = 3;
  const [bookCounter, setBookCounter] = React.useState(initialValue);
  let newBook;
  const book = [{
    id: 24,
    title: 'The Three Bears',
    author: 'Rofl Kadal',
    category: 'Fantasy',
    status: 'Borrowed',
    returnDate: '08-05-2022'}];
const [borrowedBooks, setBorrowedBooks] = useState(book);
  const dispatch = useDispatch();
  const columns = [ {
    dataField: 'title',
    text: 'Book Name',
    filter: textFilter()
  },{
    dataField: 'author',
    text: 'Author Name',
    filter: textFilter()
  },{
    dataField: 'category',
    text: 'Category',
    filter: textFilter()
  },{
    dataField: 'status',
    text: 'Status'
  },
  {
    dataField: 'returnDate',
    text: 'Return Date'
  }];
  let products = bookDetails;
  const tableRowEvents = {
    onClick: (e, row, rowIndex) => {
      if(row.status == 'Borrowed') {
        e.stopPropagation();
        setModalShow(true);
      } else if(row.status == 'Available'){
       let Counter = bookCounter + 1;
        setBookCounter(Counter);
        newBook = {
          id: row.id,
          title: row.title,
          author: row.author,
          category: row.category,
          status: "Borrowed",
          returnDate: "22-05-2022"
        }
        console.log('borrowedBooks',borrowedBooks);
       dispatch(storeData(newBook));
        
        navigate('/borrowedBooks', {
          state: borrowedBooks
        });
        e.preventDefault();
        e.stopPropagation();

      }
    }
 }
 const pagination = paginationFactory({
  page: 1,
  sizePerPage: 5,
  lastPageText: '>>',
  firstPageText: '<<',
  nextPageText: '>',
  prePageText: '<',
  showTotal: true,
  alwaysShowAllBtns: true
});
    return (
      <div>
        <h3 className="mt-4 mb-4">List Of Books</h3>
      <BootstrapTable hover keyField='id' data={ products } rowEvents={ tableRowEvents } columns={ columns } filter={ filterFactory() }  pagination={pagination}/>
      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      </div>
      
     );
   }

   function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Book is already Borrowed 
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
          Please select another book which is available
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }
   