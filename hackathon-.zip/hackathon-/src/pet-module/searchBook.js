import React, { useContext, useEffect, useState } from "react";
import { Button, Table, Modal} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { petDetailsContext } from "./pet-dashboard";
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { storeData } from "../store/reducer";
import MyModalComponent from "./modalComponent";
require('react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css');
var bookDetails = require('../json-data/books.json');

export default function SearchBook(props) {
  const navigate = useNavigate();
  const [modalShow, setModalShow] = React.useState(false);
  const [modalShowFlag, setModalShowFlag] = React.useState(false);
  var data = [];
  let initialVal = {
    show: false,
    title: '',
    body: ''
  };
  const [modalData, setModalData]= useState(initialVal);
  const state = useSelector((state) => state);
  let newBook;
  var book = [];
  const dispatch = useDispatch();
  const columns = [ {
    dataField: 'title',
    text: 'Book Name',
    filter: textFilter()
  },{
    dataField: 'author',
    text: 'Author Name',
    filter: textFilter()
  },{
    dataField: 'category',
    text: 'Category',
    filter: textFilter()
  },{
    dataField: 'status',
    text: 'Status'
  },
  {
    dataField: 'returnDate',
    text: 'Return Date'
  }];
  let products = bookDetails;
  const tableRowEvents = {
    onClick: (e, row, rowIndex) => {
      if(row.status == 'Borrowed') {
        e.stopPropagation();
        setModalShow(true);
      } else if(row.status == 'Available'){
        newBook = {
          id: row.id,
          title: row.title,
          author: row.author,
          category: row.category,
          status: "Borrowed",
          returnDate: "22-05-2022"
        }
        if(state.data.length === 0){
          book.push(newBook)
          dispatch(storeData(book));
          setModalShowFlag(true);
        } else {
          book = [];
          book.push(newBook);
          data = book.concat(state.data); 
          if(data.length > 3){
            setModalShowFlag(false);
            initialVal = {
              show: true,
              title: 'Borrowed Book Limit Exceeded',
              body: 'Limit of book a person can borrow is 3. you have exceeded the limit. Please Return the book to borrow new book',
            }
            setModalData(initialVal);
           } else {
            dispatch(storeData(data));
            setModalShowFlag(true);
          }
        }
        e.preventDefault();
        e.stopPropagation();

      }
    }
 }
 const pagination = paginationFactory({
  page: 1,
  sizePerPage: 5,
  lastPageText: '>>',
  firstPageText: '<<',
  nextPageText: '>',
  prePageText: '<',
  showTotal: true,
  alwaysShowAllBtns: true
});
const handleClose = (fromModal) => {
  setModalData({
    show: false
  });
};
useEffect (()=> {
  console.log('data', data);
  if(modalShowFlag === true) {
    navigate('/borrowedBooks'); 
  }
},[modalShowFlag]) 
    return (
      <div>
        <h3 className="mt-4 mb-4">List Of Books</h3>
      <BootstrapTable hover keyField='id' data={ products } rowEvents={ tableRowEvents } columns={ columns } filter={ filterFactory() }  pagination={pagination}/>
      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      <MyModalComponent
          show={modalData.show}
          title={modalData.title}
          body={modalData.body}
          onClick={handleClose}
          onHide={handleClose} />
      </div>
      
     );
   }

   function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Book is already Borrowed 
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
          Please select another book which is available
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }
   