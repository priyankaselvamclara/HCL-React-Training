import { render, screen } from '@testing-library/react';
import React from 'react';
import Enzyme, { mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { BrowserRouter, Route, Routes } from 'react-router-dom';


Enzyme.configure({ adapter: new Adapter() });

import { configure, shallow } from 'enzyme';
import { unmountComponentAtNode } from 'react-dom';
import { act } from 'react-test-renderer';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { Button, Form } from 'react-bootstrap';
import BorrowedBooks from './borrowedBooks';
const mockedUsedNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
   ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

describe ('testing the counter',()=>{
  let initialValue = 3
  const mockStore = configureStore();
  let store;
  beforeEach(() => {
    act(() => {
      store = mockStore(initialValue);
      let { getByText } = render(
          <Provider store={store}>
              <BorrowedBooks />
          </Provider>
      );
      //console.log('getByText',getByText);
    });
  });
  test('test store data', () => {
    expect(initialValue).not.toBeNull();
  }); 
  test('find pet list', () => {
    expect(screen.getByText('Borrowed Books'))
  });
  test('find pet list', () => {
    expect(screen.getByText('Borrowed Book'))
  });
  it('Test click event', () => {
    const mockCallBack = jest.fn();
    const button = shallow((<Button onClick={mockCallBack}>Close</Button>));
    button.find('button').simulate('click');
    expect(mockCallBack.mock.calls.length).toEqual(1);
  });
  it('Test button value', () => {
    const mockCallBack = jest.fn();
    const button = shallow((<Button id="#btn" variant="primary" className="mt-4 mb-4" onClick={mockCallBack}>Submit</Button>));
    expect(button.text()).toContain('Submit');
  });
  
});
