import { Table } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { Header } from "./header";

export default function MyPets(props) {
  const {state} = useLocation();
  console.log('state',state);
    return (
       <div className='MyPets'>
          <div>
         <h1>My Pets</h1>
        <Table striped bordered hover>
              <thead>
                  <tr>
                    <th>Pet Id</th>
                    <th>Pet Name</th>
                    <th>Pet Type</th>
                    <th>Pet Breed</th>
                  </tr>
              </thead>
              <tbody>
                  {
                   state.map((pet, i) => {
                          return (
                              <tr key={i}>
                                  <td>{pet.id}</td>
                                  <td>{pet.name}</td>
                                  <td>{pet.type}</td>
                                  <td>{pet.breed}</td>
                              </tr>
                          )
                      })
                  }
              </tbody>
          </Table>

    </div>
        
       </div>
     );
   }