import React, { forwardRef } from "react";
import { FixedSizeGrid as Grid } from "react-window";

import "../css-components/pets.css";
var petSInfo = require('../json-data/pets.json');
const GUTTER_SIZE = 5;
const COLUMN_WIDTH = 100;
const ROW_HEIGHT = 35;
console.log('petSInfo,petSInfo', petSInfo)
const pet = ({style}) =>{ 
  petSInfo.map(function(patient, index){
  

  
 
      <div key={index}
    className="GridItem"
    style={{
      ...style,
      left: style.left + GUTTER_SIZE,
      top: style.top + GUTTER_SIZE,
      width: style.width - GUTTER_SIZE,
      height: style.height - GUTTER_SIZE
    }} value={patient.name}
  >
   
  </div>
  })
  }
 
export const Table = () => (

  <Grid 
    className="Grid"
    columnCount={5}
    columnWidth={COLUMN_WIDTH + GUTTER_SIZE}
    height={300}
    innerElementType={innerElementType}
    rowCount={5}
    rowHeight={ROW_HEIGHT + GUTTER_SIZE}
    width={400}
  >
    {pet}
  </Grid>
);
const innerElementType = forwardRef(({ style, ...rest }, ref) => (
  <div
    ref={ref}
    style={{
      ...style,
      paddingLeft: GUTTER_SIZE,
      paddingTop: GUTTER_SIZE
    }}
    {...rest}
  />
));