
export function Footer(props) {
    return (
       <div className='Footer'>
              Footer
       </div>
     );
   }
   