import React from "react";
import { Navbar, Container, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
import '../css-components/header.css'

export function Header(props) {
    return (
       <div className='header'>
             <Navbar bg="primary" variant="dark">
            <Container>
                <Navbar.Brand href="/home">Library</Navbar.Brand>
                <Nav className="me-auto">
                    <Nav.Link href="/home">Home</Nav.Link>
                    <Nav.Link href="/borrowedBooks">Borrowed Books</Nav.Link>
                    {/* <Nav.Link href="/addPets">Add Pet</Nav.Link>
                    <Nav.Link href="/logout">Logout</Nav.Link> */}
                </Nav>
            </Container>
        </Navbar>
       </div>
     );
   }
   