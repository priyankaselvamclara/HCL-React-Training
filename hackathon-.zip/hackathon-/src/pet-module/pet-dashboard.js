//import { Footer } from "./footer";
import { createContext } from "react";
import { useLocation } from "react-router-dom";
import { Header } from "./header";
import SearchBook from "./searchBook";
//import "react-virtualized/styles.css"; // only needs to be imported once
import PetHomePage  from "./searchBook";
//import {Table} from '../pet-module/pets';
export const petDetailsContext= createContext(null);

export default function PetDashboard(props) {

    return (
       <div className='PetDashboard'>
          <SearchBook />
       </div>
     );
   }
   