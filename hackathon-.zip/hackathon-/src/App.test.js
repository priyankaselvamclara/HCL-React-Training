import { render, screen } from '@testing-library/react';
import App from './App';
import React from 'react';

import { configure, shallow } from 'enzyme';
import { PetRouter } from './pet-router';
import { Header } from './pet-module/header';

describe ('testing the counter',()=>{
  let wrapper;
  beforeEach(()=> {
    wrapper = shallow(<App />);
    //console.log(wrapper.debug());
  })
  it("renders PetRouter component without crashing", () => {
    shallow(<PetRouter />);
  });
  it("renders PetRouter component without crashing", () => {
    shallow(<Header />);
  });
  // test('renders title text', () => {
  //   expect(wrapper.find('h1').text()).toContain('Counter');
  // });
  // test('renders button text', () => {
  //   expect(wrapper.find('#btn').text()).toContain('Increment');
  // });
  // test('initial value to be o', () => {
  //   expect(wrapper.find('#counter').text()).toContain('0');
  // // });
  /*test('value to be 1 onClick', () => {4az
    wrapper.find('#btn').simulate('click');
    expect(wrapper.find('#counter').text()).toContain('1');
  });*/
  // it('sets the state componentDidMount', async () => {
  //   window.fetch = jest.fn().mockImplementation(() => {
  //     return new Promise((resolve, reject) => {
  //         resolve({
  //             status: 200,
  //             ok: true,
  //             json: () => new Promise((resolve, reject) => {
  //                 resolve({
  //                     'text': [
  //                         { 'firstname': 'Robbie', 'lastname': 'Keane' },
  //                         { 'firstname': 'Alan', 'lastname': 'Shearer' }
  //                     ]
  //                 });
  //             })
  //         });
  //     });
  //     //const renderedComponent = await shallow(<App />)
  //     wrapper.update()
  //     expect(wrapper.state('text').length).toEqual(2)
  // })
      
//})
});

