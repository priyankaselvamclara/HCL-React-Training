import './App.css';
import { Header } from './pet-module/header';
import { PetRouter } from './pet-router';

function App() {
  
  return (
    <div className="App">
      
      <PetRouter />
    </div>
  );
}

export default App;
