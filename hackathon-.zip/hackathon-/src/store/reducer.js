import {fetchRecords, storeRecord} from './actionCreater'
export const storeData = (data) => {
    console.log('am called storeData', data)
    return (dispatch) => {dispatch(storeRecord(data))};
}
export const fetchData = (data, name) => {
    console.log('am called fetchData', data, name)
    let message = '';
    if(data.name === name) {
        message = 'user exist';
    }
     console.log('**************** editedData',message);
    return (dispatch) => {dispatch(fetchRecords(message))};
}

