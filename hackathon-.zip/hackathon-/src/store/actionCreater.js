import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    data:[], error:'', message: ''
}

export const counterSlice = createSlice({
  name: 'fetch',
  initialState,
  reducers: {
    storeRecord: (state, action) => {
        console.log("&&&&&&&&&&& storeRecord",action.payload);
        state.data = action.payload;
    
    },
    fetchRecords: (state, action) => {
     console.log("&&&&&&&&&&& fetchRecords",state, action)
     state.message = action.payload;
     console.log("state.message fetchRecords",state.message)
    },
  }
})


// Action creators are generated for each case reducer function
export const { storeRecord, fetchRecords } = counterSlice.actions

export default counterSlice.reducer;