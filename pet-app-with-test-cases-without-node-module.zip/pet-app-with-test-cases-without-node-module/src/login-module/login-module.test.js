import { render, screen } from '@testing-library/react';
import Login from './login';
import React from 'react';
//import Enzyme, { mount } from 'enzyme';
//import Adapter from 'enzyme-adapter-react-16';
//import { BrowserRouter, Route, Routes } from 'react-router-dom';


//Enzyme.configure({ adapter: new Adapter() });

import { shallow } from 'enzyme';
//import { unmountComponentAtNode } from 'react-dom';
import { act } from 'react-test-renderer';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { Button, Form } from 'react-bootstrap';
const mockedUsedNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
   ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

describe ('testing the counter',()=>{
  let wrapper;
  let initialState = {
    name: 'priyanka.selvam@hcl.com',
    password: 'Beautiful@123',
  }
  const mockStore = configureStore();
  let store;
  beforeEach(() => {
    act(() => {
      store = mockStore(initialState);
      let { getByText } = render(
          <Provider store={store}>
              <Login />
          </Provider>
      );
      console.log('getByText',getByText);
    });
  });
  test('test store data', () => {
    expect(initialState).not.toBeNull();
  }); 
  test('find pet list', () => {
    expect(screen.getByText('Login'))
  });
  it('Test click event', () => {
    const mockCallBack = jest.fn();
    const button = shallow((<Button id="#btn" variant="primary" className="mt-4 mb-4" onClick={mockCallBack}>Submit</Button>));
    button.find('button').simulate('click');
    expect(mockCallBack.mock.calls.length).toEqual(1);
  });
  it('Test button value', () => {
    const mockCallBack = jest.fn();
    const button = shallow((<Button id="#btn" variant="primary" className="mt-4 mb-4" onClick={mockCallBack}>Submit</Button>));
    expect(button.text()).toContain('Submit');
  });
  it('check form', () => {
    const formEventMocked = { handleSubmit: jest.fn() };
    wrapper = shallow(<Form onSubmit={formEventMocked.handleSubmit}></Form>);
    expect(formEventMocked.handleSubmit).toBeCalledTimes(0);
    expect(wrapper.find('form')).toHaveLength(1);
  });
  it('Test click event', () => {
    const mockCallBack = jest.fn();
    const button = shallow(<Button id="#btn" variant="primary" className="mt-4 mb-4" onClick={mockCallBack}>Submit</Button>);
    button.find('button').simulate('click');
    expect(mockCallBack.mock.calls.length).toEqual(1);
  });
});
