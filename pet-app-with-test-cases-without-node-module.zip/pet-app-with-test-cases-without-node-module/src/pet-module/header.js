import React from "react";
import { Navbar, Container, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
import '../css-components/header.css'

export function Header(props) {
    return (
       <div className='header'>
             <Navbar bg="primary" variant="dark">
            <Container>
                <Navbar.Brand href="/home">Pets</Navbar.Brand>
                <Nav className="me-auto">
                    <Link to="/home">Home</Link>
                    <Link to="/home/myPets">My Pets</Link>
                    <Link to="/home/addPets">Add Pet</Link>
                    <Link to="/logout">Logout</Link>
                </Nav>
            </Container>
        </Navbar>
       </div>
     );
   }
   