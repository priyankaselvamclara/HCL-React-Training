import { render, screen } from '@testing-library/react';
import PetHomePage from './pet-home-page';
//import Enzyme, { mount } from 'enzyme';
//import Adapter from 'enzyme-adapter-react-16';
var petSInfo = require('../json-data/pets.json');

//Enzyme.configure({ adapter: new Adapter() });
import React from 'react';

//import { configure, shallow } from 'enzyme';
import { act } from 'react-test-renderer';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { unmountComponentAtNode } from 'react-dom';

describe ('testing the pet dashboard',()=>{
    let container = null;
    beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    act(() => {
        render(
        <BrowserRouter>
            <Routes>   
                <Route path="*" element= {<PetHomePage />}/>
            </Routes>
        </BrowserRouter>
            , container);
        });
});

afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});
  test('find pet list', () => {
    expect(screen.getByText('List of Pets'))
});
test('table title', () => {
    expect(screen.findByText('Pet Id'));
    expect(screen.findByText('Pet Name'));
    expect(screen.findByText('Pet Type'));
    expect(screen.findByText('Pet Breed'));
    expect(screen.findByText('Pet status'));
});
test('table data', () => {
   React.useState = jest.fn().mockReturnValue(petSInfo)
   expect(screen.findByText('Threas Divya'));
   expect(screen.findByText('Sherin'));
   expect(screen.findByText('Parrot'));
   expect(screen.findByText('Dog'));
   expect(screen.findByText('Cat'));
   expect(screen.findByText('sold'));
   expect(screen.findByText('Buy'));
   expect(screen.findByText('Rabbit'));
});
/*test("should call addMyPets callback", () => {
    const addMyPetsSpy = jest.fn();
    const { getByTestId } = render( <PetHomePage />);
    fireEvent.click(getByTestId('pet'));
    expect(addMyPetsSpy).toHaveBeenCalled();
  });*/
})

