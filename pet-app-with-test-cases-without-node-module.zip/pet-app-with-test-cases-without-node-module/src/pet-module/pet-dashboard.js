//import { Footer } from "./footer";
import { createContext } from "react";
import { useLocation } from "react-router-dom";
import { Header } from "./header";
//import "react-virtualized/styles.css"; // only needs to be imported once
import PetHomePage  from "./pet-home-page";
//import {Table} from '../pet-module/pets';
export const petDetailsContext= createContext(null);

export default function PetDashboard(props) {
  const {state} = useLocation();
  console.log('state',state);
 
    return (
       <div className='PetDashboard'>
         <Header />  
         <petDetailsContext.Provider value={state}>
          <PetHomePage />
         </petDetailsContext.Provider>
       </div>
     );
   }
   