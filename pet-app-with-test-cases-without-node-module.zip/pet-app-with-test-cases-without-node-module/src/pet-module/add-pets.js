import { Header } from "./header";
import {Form,Row,Col,Button} from 'react-bootstrap';
import { useState } from "react";
import '../css-components/add-pets.css'
import { useNavigate } from "react-router-dom";

export default function AddPets(props) {
  const [validated, setValidated] = useState(false);
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === true) {
      event.preventDefault();
      event.stopPropagation();
    }
   let petDetails = {
        id: event.target[0].value,
        name: event.target[1].value,
        type: event.target[2].value,
        breed: event.target[3].value,
        status: "Buy"
    }
    console.log('petDetails',petDetails);
    
    setTimeout(() => {
        navigate('/home', {
            state: petDetails});
    }, 500)
    setValidated(true);
  };
  return (
      <div className='AddPets'>
        <Header />
        <h2> Add your Pet</h2>
        <Form validated={validated} onSubmit={handleSubmit}>
          <Row className="mb-3">
          <Form.Group as={Col} md="12" controlId="validationCustomId">
              <Form.Label className='col-md-2'>Id</Form.Label>
              <Form.Control className='col-md-4 mb-3' 
                  required
                  type="number"
                  placeholder="id" />
          </Form.Group>
          <Form.Group as={Col} md="12" className="form-block" controlId="validationCustomName">
              <Form.Label  className='col-md-2'>Name</Form.Label>
              <Form.Control  className='col-md-4 mb-3' 
                  required
                  type="text" name="name" 
                  placeholder="Name" />
                  
          </Form.Group>
          <Form.Group as={Col} md="12" controlId="validationCustomPet">
              <Form.Label className='col-md-2'>Type of Pet</Form.Label>
              <Form.Select className='col-md-4 mb-3' aria-label="select Pet" required>
                  <option>select menu</option>
                  <option value="Cat">Cat</option>
                  <option value="Dog">Dog</option>
                  <option value="Rabbit">Rabbit</option>
                  <option value="Parrot">Parrot</option>
                  <option value="Others">Others</option>
              </Form.Select>
          </Form.Group>
          <Form.Group as={Col} md="12" className="form-block" controlId="validationCustomBreed">
              <Form.Label  className='col-md-2'>Breed</Form.Label>
              <Form.Control  className='col-md-4 mb-3' 
                  required
                  type="text" name="breed" 
                  placeholder="Breed" />
                  
          </Form.Group>
      </Row>
      <Button type="submit">Submit</Button>
  </Form>
      </div>
    );
  }
   