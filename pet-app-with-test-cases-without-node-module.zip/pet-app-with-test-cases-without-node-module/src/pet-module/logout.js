import { useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";

export default function Logout(props) {
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => {
      navigate('/');
    }, 600) 
  },[])
    return (
       <div className='Logout mt-6'>
              You have been Logout Succesfully !! 
       </div>
     );
   }