import React, { useContext, useEffect, useState } from "react";
import { Button, Table } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { petDetailsContext } from "./pet-dashboard";
var petSInfo = require('../json-data/pets.json');

export default function PetHomePage(props) {
  const petContextData = useContext(petDetailsContext);
  const [petDetails, setPetDetails] = React.useState(petSInfo);
    
  const navigate = useNavigate();
  useEffect(() => {
    console.log('context data', petContextData);
    if (petContextData) {
      setPetDetails([
        ...petDetails,
        petContextData
    ]);
    }
    //console.log('coo', petDetails);
}, [])
  const addMyPets = (pet) => {
    let data =[];
    data.push(pet);
    navigate("myPets", {
      state: data})
  }

    return (
       <div className='PetHomePage'>
         <h1>List of Pets</h1>
        <Table striped bordered hover>
              <thead>
                  <tr>
                    <th>Pet Id</th>
                    <th>Pet Name</th>
                    <th>Pet Type</th>
                    <th>Pet Breed</th>
                    <th>Pet status</th>
                  </tr>
              </thead>
              <tbody>
                  {
                   petDetails.map((pet, i) => {
                          return (
                              <tr key={i}>
                                  <td>{pet.id}</td>
                                  <td>{pet.name}</td>
                                  <td>{pet.type}</td>
                                  <td>{pet.breed}</td>
                                  <td>
                                      <div className="d-flex">
                                          <Button variant="primary" disabled={pet.status === 'sold'?"true":"false"} onClick={()=>addMyPets(pet)}
                                              className="d-flex ms-auto me-3" size="sm">{pet.status}</Button>
                                      </div>
                                  </td>
                              </tr>
                          )
                      })
                  }
              </tbody>
          </Table>
       </div>
     );
   }
   