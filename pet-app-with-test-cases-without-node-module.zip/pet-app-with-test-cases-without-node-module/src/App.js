import { useState } from 'react';
import './App.css';
import { PetRouter } from './pet-router';

function App() {
  let initialValue = 0;
  const [text, setText] = useState("");
  
  const getAsyncApiData = async()=> {
    await fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res => res.json())
    .then((result) => {
      console.log(JSON.stringify(result));
      setText(result); 
    })
  }
  const [counter, setCounter] = useState(0);
  return (
    <div className="App">
      <h1>Counter</h1>
      <PetRouter />
      <div id="counter">{counter}</div>
      <button id="btn" onClick={()=>setCounter(counter+1)}>Increment</button>
     
      <button data-testid="apiCall" onClick={() => getAsyncApiData()}>Make API call</button>
    </div>
  );
}

export default App;
