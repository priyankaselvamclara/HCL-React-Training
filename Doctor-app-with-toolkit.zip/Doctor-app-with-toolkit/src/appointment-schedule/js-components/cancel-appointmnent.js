
export function CancelAppointmnent(props) {
  
 return (
    <div className='cancelAppointmnent'>
           CancelAppointmnent
    </div>
  );
}
