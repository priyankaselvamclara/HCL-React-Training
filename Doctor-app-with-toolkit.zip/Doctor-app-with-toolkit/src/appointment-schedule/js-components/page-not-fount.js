
export function PageNotFount(props) {
 return (
    <div className='cancelAppointmnent'>
           CancelAppointmnent
    </div>
  );
}
