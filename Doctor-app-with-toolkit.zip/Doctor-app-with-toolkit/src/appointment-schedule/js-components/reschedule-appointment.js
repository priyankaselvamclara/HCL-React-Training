



export function RescheduleAppointment(props) {

  return (
    <div className='rescheduleAppointment'>
           RescheduleAppointment
    </div>
  );
}
